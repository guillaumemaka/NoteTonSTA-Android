package com.supinfo.exception;

public class SpeakerUpdateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SpeakerUpdateException() {
		// TODO Auto-generated constructor stub
	}

	public SpeakerUpdateException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public SpeakerUpdateException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public SpeakerUpdateException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
