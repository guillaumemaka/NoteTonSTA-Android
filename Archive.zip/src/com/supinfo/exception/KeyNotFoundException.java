package com.supinfo.exception;

public class KeyNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public KeyNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KeyNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public KeyNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public KeyNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
