package com.supinfo.exception;

public class CampusCreationExecption extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CampusCreationExecption() {
		// TODO Auto-generated constructor stub
	}

	public CampusCreationExecption(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CampusCreationExecption(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public CampusCreationExecption(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
