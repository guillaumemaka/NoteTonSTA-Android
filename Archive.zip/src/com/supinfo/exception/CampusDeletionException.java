package com.supinfo.exception;

public class CampusDeletionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CampusDeletionException() {
		// TODO Auto-generated constructor stub
	}

	public CampusDeletionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CampusDeletionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public CampusDeletionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
