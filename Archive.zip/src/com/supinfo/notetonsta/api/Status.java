package com.supinfo.notetonsta.api;

public enum Status {
	ERROR, OK, CREATION_FAIL, DELETION_FAIL, UPDATE_FAIL, OBJECT_NOT_FOUND
}
