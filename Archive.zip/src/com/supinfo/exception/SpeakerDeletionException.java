package com.supinfo.exception;

public class SpeakerDeletionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SpeakerDeletionException() {
		// TODO Auto-generated constructor stub
	}

	public SpeakerDeletionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SpeakerDeletionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SpeakerDeletionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
