package com.supinfo.exception;

public class MarkCreationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MarkCreationException() {
		// TODO Auto-generated constructor stub
	}

	public MarkCreationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MarkCreationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public MarkCreationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
