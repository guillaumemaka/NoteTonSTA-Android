package com.supinfo.exception;

public class SpeakerCreationException extends Exception {

	private static final long serialVersionUID = 1L;

	public SpeakerCreationException() {
		// TODO Auto-generated constructor stub
	}

	public SpeakerCreationException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public SpeakerCreationException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public SpeakerCreationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
