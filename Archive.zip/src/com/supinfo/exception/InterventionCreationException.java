package com.supinfo.exception;

public class InterventionCreationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InterventionCreationException() {
		// TODO Auto-generated constructor stub
	}

	public InterventionCreationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InterventionCreationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InterventionCreationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
