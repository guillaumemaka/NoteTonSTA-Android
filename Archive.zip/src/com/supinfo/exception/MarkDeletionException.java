package com.supinfo.exception;

public class MarkDeletionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MarkDeletionException() {
		// TODO Auto-generated constructor stub
	}

	public MarkDeletionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MarkDeletionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public MarkDeletionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
