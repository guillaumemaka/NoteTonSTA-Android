package com.supinfo.exception;

public class MarkUpdateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MarkUpdateException() {
		// TODO Auto-generated constructor stub
	}

	public MarkUpdateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MarkUpdateException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public MarkUpdateException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
